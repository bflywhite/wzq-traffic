count=0
let count++
echo $count
