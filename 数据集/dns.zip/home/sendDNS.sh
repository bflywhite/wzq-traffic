for line in `cat file domain.txt`
do
	echo $line
    nslookup $line
    sleep 3
done
